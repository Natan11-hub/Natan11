﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalTask
{
    class Program
    {
        static void Pause()
        {
            Console.ReadLine();
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Не совсем понял финальное задание, так что просто набросал сюда немного информации о себе");
            Console.WriteLine("Моя фамилия: " + mySurname("Мартынов"));
            Console.WriteLine("Мой возраст: "+ Param(21));
            Pause();
        }
        static string mySurname(string surname)
        {
            return surname;
        }
        static double Param(double w)
        {
            return w;
        }
    }
}
