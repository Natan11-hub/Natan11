﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swap
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Введите значение а: ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение b: ");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine($"Изначальные значения: {a}, {b}");
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine($"Смена значений: {a}, {b}");
            Console.ReadKey();
        }
    }
}
