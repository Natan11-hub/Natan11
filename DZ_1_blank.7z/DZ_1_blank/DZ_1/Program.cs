﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ_1
{
    class Program
    {
  
        static void Chest()
        {
            Console.WriteLine("Укажите ваше имя: ");
            string name = Console.ReadLine();
            Console.WriteLine("Укажите вашу фамилию: ");
            string surname = Console.ReadLine();
            Console.WriteLine("Укажите ваш возраст: ");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Укажите ваш рост: ");
            int growt = int.Parse(Console.ReadLine());
            Console.WriteLine("Укажите ваш вес: ");
            int weight = int.Parse(Console.ReadLine());
            Console.WriteLine($"Имя: {name}  Фамилия: {surname} Возраст: {age} Рост: {growt} Вес: {weight}");
            Console.ReadLine();
        }
        static void Main(string[] args)
        {
            Chest();
        }
    }
}
