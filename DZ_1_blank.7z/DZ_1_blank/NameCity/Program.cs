﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NameCity
{
    class Program
    {
        static string Value(string name, string surname, string city)
        {
            return name + " " + surname + ", " + city;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите имя: ");
            string userName = Console.ReadLine();
            Console.WriteLine("Введите фамилию: ");
            string userSurname = Console.ReadLine();
            Console.WriteLine("Введите город: ");
            string userCity = Console.ReadLine();
            string result = Value(userName, userSurname, userCity);
            Console.WriteLine("{0,70}", result);
            Console.ReadKey();
        }
    }
}
