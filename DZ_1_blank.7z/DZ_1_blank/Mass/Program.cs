﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mass
{
    class Program
    {
        public static double Form(double m, double h)
        {
            return m / (h * h);
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите ваш вес: ");
            int mass = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите ваш рост через запятую: ");
            double height = double.Parse(Console.ReadLine());
            double i = Form(mass, height);
            Console.WriteLine("Индекс массы вашего тела: " + i);
            Console.ReadKey();
        }
        
    }
}
