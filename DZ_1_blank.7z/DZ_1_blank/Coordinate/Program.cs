﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coordinate
{
    class Program
    {
        static double answer(double x1, double x2, double y1, double y2)
        {
            double r = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
            return r;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите координату х1: ");
            int xx1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите координату х2: ");
            int xx2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите координату y1: ");
            int yy1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите координату y2: ");
            int yy2 = int.Parse(Console.ReadLine());

            double result = answer(xx1,xx2,yy1,yy2);
            Console.WriteLine("Расстояние между точками: " + "{0:F2}", result);
            Console.ReadKey();
        }
    }
}
